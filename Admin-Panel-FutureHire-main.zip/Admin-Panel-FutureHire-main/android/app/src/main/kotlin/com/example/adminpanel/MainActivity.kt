package com.example.adminpanel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
