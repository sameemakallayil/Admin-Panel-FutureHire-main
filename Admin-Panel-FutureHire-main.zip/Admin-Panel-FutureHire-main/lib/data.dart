double height = 0.0;
double width = 0.0;
